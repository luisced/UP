#include "utills.cpp"

int main()
{
    system("clear");
    menu();
    return 0;
}
